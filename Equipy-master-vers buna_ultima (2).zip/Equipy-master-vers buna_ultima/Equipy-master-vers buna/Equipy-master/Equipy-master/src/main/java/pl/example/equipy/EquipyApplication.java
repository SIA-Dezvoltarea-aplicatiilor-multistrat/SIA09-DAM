package pl.example.equipy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EquipyApplication {

    public static void main(String[] args) {
        SpringApplication.run(EquipyApplication.class, args);
    }
}
