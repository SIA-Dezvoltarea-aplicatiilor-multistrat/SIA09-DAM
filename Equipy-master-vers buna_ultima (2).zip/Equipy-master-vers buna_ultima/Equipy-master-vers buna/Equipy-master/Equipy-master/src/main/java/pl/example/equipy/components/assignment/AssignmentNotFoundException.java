package pl.example.equipy.components.assignment;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Nu există nicio atribuire cu acest ID")
class AssignmentNotFoundException extends RuntimeException { }