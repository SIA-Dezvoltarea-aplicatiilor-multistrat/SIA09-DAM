'use strict';
angular.module('app', ['ngRoute', 'ngResource']);