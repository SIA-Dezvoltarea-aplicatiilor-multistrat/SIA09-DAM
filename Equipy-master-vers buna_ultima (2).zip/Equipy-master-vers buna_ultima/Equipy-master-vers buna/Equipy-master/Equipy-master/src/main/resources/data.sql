insert into user(id, first_name, last_name, pesel) values
  (1, 'Ion', 'Popescu', '90101222457'),
  (2, 'Vasile', 'Lupu', '87112242456'),
  (3, 'Andrei', 'Popa', '76061536749'),
  (4, 'George', 'Ionescu', '82010877245');
  insert into category(id, name, description) values
  (1, 'Laptop-uri', 'Computere personale portabile'),
   (2, 'Telefoane', 'Computer hardware mic'),
   (3, 'Vehicule', 'Masini si scutere');
   insert into asset(id, name, description, serial_number, category_id) values
  (1, 'Asus MateBook D', '15 inch laptop, i5, 8GB DDR3, culoare neagra', 'ASMBD198723', 1),
  (2, 'Apple MacBook Pro 2015', '13 inch laptop, i5, 16GB DDR3, SSD256GB, culoare argintie', 'MBP15X0925336', 1),
  (3, 'Dell Inspirion 3576', '13 inch laptop, i7, 8GB DDR4, SSD 512GB, culoare neagra', 'DI3576XO526716', 3),
  (4, 'Lenovo Thinkpad X1 Carbon', '14 inch laptop, i5, 8GB DDR4, SSD 128GB, culoare neagra', 'LTX1C8KA78220', 1),
  (5, 'Samsung Note 8', 'Set complet: telefon, căști, încărcător', 'SN882017AX896B', 2),
  (6, 'Xiaomi Mi Mix 2', 'Telefon', 'XMM2S78A6652J', 2),
  (7, 'Apple iPhone X', 'Telefon si casti', 'APLX17287GHX21', 2),
  (8, 'Apple iPhone 8', 'Telefon si casti', 'APL8185652HGT7', 2),
  (9, 'Opel Insignia GSi', 'autoturism, cutie de viteze automata in 6 trepte, motor benzina 2.0', 'XHG78K64', 3),
  (10, 'Ford Focus', 'masina, 5 cutie de viteze manuala, motor diesel 1.6', 'M24HP88GYJ', 3);
  insert into assignment(id, start, end, asset_id, user_id) values
  (1, '2017-10-08 15:00:00', '2018-10-08 15:00:00', 1, 1),
  (2, '2018-10-09 12:00:00', null, 5, 1),
  (3, '2018-10-10 16:00:00', null, 9, 1);