package myspace;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ManagEchip extends Echipament {
 
   private List<Echipament> listEchipament = new ArrayList<Echipament>();
   private String ultimaVerificare;
   @Entity
public List<Echipament> getListEchipament() {
	return listEchipament;
}
public void setListEchipament(List<Echipament> listEchipament) {
	this.listEchipament = listEchipament;
}
public String getUltimaVerificare() {
	return ultimaVerificare;
}
public void setUltimaVerificare(String ultimaVerificare) {
	this.ultimaVerificare = ultimaVerificare;
}
@Override
public String toString() {
	return "ManagEchip [listEchipament=" + listEchipament + ", ultimaVerificare=" + ultimaVerificare + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = super.hashCode();
	result = prime * result + Objects.hash(listEchipament, ultimaVerificare);
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (!super.equals(obj))
		return false;
	if (getClass() != obj.getClass())
		return false;
	ManagEchip other = (ManagEchip) obj;
	return Objects.equals(listEchipament, other.listEchipament)
			&& Objects.equals(ultimaVerificare, other.ultimaVerificare);
}
public ManagEchip() {
	super();
	// TODO Auto-generated constructor stub
}
   
	
}
