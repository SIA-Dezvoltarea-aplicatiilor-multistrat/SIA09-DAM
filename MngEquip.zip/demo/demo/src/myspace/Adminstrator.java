package myspace;

import java.util.Objects;
@Entity
public class Adminstrator extends Angajat {
	private String loginStatus;

	public String getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(String loginStatus) {
		this.loginStatus = loginStatus;
	}

	@Override
	public String toString() {
		return "Adminstrator [loginStatus=" + loginStatus + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(loginStatus);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Adminstrator other = (Adminstrator) obj;
		return Objects.equals(loginStatus, other.loginStatus);
	}

	public Adminstrator() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
