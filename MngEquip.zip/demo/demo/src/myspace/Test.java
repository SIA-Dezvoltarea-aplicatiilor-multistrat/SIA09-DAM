package myspace;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public Test() {
		super();
		// TODO Auto-generated constructor stub
	}

}
