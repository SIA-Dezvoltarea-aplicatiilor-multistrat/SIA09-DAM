package myspace;

import java.util.Objects;
@Entity
@Table(name="Echipament")
public class Echipament {
	
	private int  id;
	private String name;
	private String status;
	private String posesor;
   @Id
   @Column(name="ID_NUMBER", updatable=true, nullable=false)
	public int getId() {
		return id;
	}
   public void setId(int id) {
		this.id = id;
	}
   @Column(name="NUME_ECHIPAMENT", nullable=false)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="STATUS", nullable=false)
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Column(name="POSESOR", nullable=false)
	public String getPosesor() {
		return posesor;
	}
	public void setPosesor(String posesor) {
		this.posesor = posesor;
	}

	@Override
	public String toString() {
		return "Echipament [id=" + id + ", name=" + name + ", status=" + status + ", posesor=" + posesor + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, posesor, status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Echipament other = (Echipament) obj;
		return id == other.id && Objects.equals(name, other.name) && Objects.equals(posesor, other.posesor)
				&& Objects.equals(status, other.status);
	}

	public Echipament() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
