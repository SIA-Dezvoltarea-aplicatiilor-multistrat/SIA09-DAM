package myspace;

import java.util.Objects;
@Entity
@Table(name="Angajat")
public class Angajat {
	
	private String name;
	private String function;
	private int  nrEcuipments;
	private String mail;
	 @Id
	 @Column(name="ID_NUMBER_ANGAJAT", updatable=true, nullable=false, autoincrement=true)
	 @Column(name="NUME_ANGAJAT", nullable=false)
	 
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="FUNCTIE", nullable=false)
	public String getFunction() {
		return function;
	}
	public void setFunction(String function) {
		this.function = function;
	}
	@Column(name="NR_ECHIPAMENTE", nullable=false)
	public int getNrEcuipments() {
		return nrEcuipments;
	}
	public void setNrEcuipments(int nrEcuipments) {
		this.nrEcuipments = nrEcuipments;
	}
	@Column(name="MAIL", nullable=false)
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	@Override
	public String toString() {
		return "Angajat [name=" + name + ", function=" + function + ", nrEcuipments=" + nrEcuipments + ", mail=" + mail
				+ "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(function, mail, name, nrEcuipments);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Angajat other = (Angajat) obj;
		return Objects.equals(function, other.function) && Objects.equals(mail, other.mail)
				&& Objects.equals(name, other.name) && nrEcuipments == other.nrEcuipments;
	}
	public Angajat() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	
	

}
