package com.example.demo;
abstract class Angajat {
  public abstract int getWheel();
  
  public String toString() {
    return "Wheel: " + this.getWheel();
  }
}

class Administrator extends Angajat{
  int wheel;
  
  Administrator(int wheel) {
    this.wheel = wheel;
  }

  @Override
  public int getWheel() {
    return this.wheel;
  }
}

class Echipament extends Angajat {
  int wheel;
  
  Echipament(int wheel) {
    this.wheel = wheel;
  }
  
  @Override
  public int getWheel() {
    return this.wheel;
  }
}

class AngajatFactory {
  public static Angajat getInstance(String type, int wheel) {
    if(type == "Administrator") {
      return new Administrator(wheel);
    } else if(type == "Echipament") {
      return new Echipament(wheel);
    }
    
    return null;
  }
}

public class FactoryPatternExample {

  public static void main(String[] args) {
    Angajat Administrator = AngajatFactory.getInstance("Administrator", 4);
    System.out.println(Administrator);
    
    Angajat Echipament = AngajatFactory.getInstance("Echipament", 2);
    System.out.println(Echipament);
  }

}